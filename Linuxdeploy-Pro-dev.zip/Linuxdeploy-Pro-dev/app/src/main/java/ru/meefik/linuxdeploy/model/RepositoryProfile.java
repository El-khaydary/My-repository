package ru.meefik.linuxdeploy.model;

public class RepositoryProfile {
    private String profile;
    private String description;
    private String type;
    private String size;

    public RepositoryProfile() {
        // Empty constructor
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}

Build pkgdetails
================

    $ ndk-build
    $ mv libs/armeabi/pkgdetails ../../app/src/main/assets/bin/arm/pkgdetails
    $ mv libs/x86/pkgdetails ../../app/src/main/assets/bin/intel/pkgdetails


Sources
=======

BusyBox: https://github.com/meefik/busybox

PRoot: https://github.com/meefik/PRoot

websocket.sh: https://github.com/meefik/websocket.sh

pkgdetails https://dev.openwrt.org/browser/packages/admin/debootstrap/files/pkgdetails.c

QEMU: https://packages.debian.org/stretch/qemu-user-static

mke2fs (e2fsprogs): http://packages.debian.org/wheezy/e2fsprogs

zstdcat (zstd): https://github.com/facebook/zstd
